<?php
/**
 *  file:   index.php
 *  desc:   Ohjaa pois kansiosta (niihin kansioihin, joita ei tarvitse näyttää)
 */
header('location: ../');
?>