<?php
/**
 *  file:   index.php
 *  desc:   Sovelluksen pääsivu. Tämän sivun kautta näytetään sisältöä esim kirjautuneelle käyttäjälle
 */
if(isset($_GET['sivu'])) $sivu=$_GET['sivu']; else $sivu='';
session_start(); //session avulla hallitaan tilaa - > onko kirjautunut vai ei
if(!isset($_SESSION['user'])) header('location: ../');
header('Cache-control: no-cache, no-store, must-revalidate');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>YritysX - Etusivu</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container">
    <?php
    if(isset($_SESSION['user'])){
         echo '<p class="alert alert-info"><b>Käyttäjä: ';
         echo '<a href="index.php?sivu=omatTiedot">'; //linkki omien tietojen muokkaamiseen
         echo $_SESSION['user'];
         echo '</a></b></p>';
    }
    ?>
    </div>
    <div class="container">
        <h2>YritysX - Admin</h2>
        <p><a href="index.php?sivu=users">Käyttäjät</a>
        <a href="logout.php">Kirjaudu ulos</a></p>
    </div>
    <div class="container">
        <?php
        if($sivu=='users') include('users.php');
        else if($sivu=='omatTiedot') include('omatTiedot.php');
        else if($sivu=='muokkaa') include('muokkaa.php');
        ?>
    </div>
</body>
</html>