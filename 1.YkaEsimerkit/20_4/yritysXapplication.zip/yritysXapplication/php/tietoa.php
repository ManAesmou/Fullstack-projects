<?php
/**
 *  file:   tietoa.php
 *  desc:   Näyttää tietoa yrityksestä
 */
?>
<div class="jumbotron">
    <h3>YritysX</h3>
    <p>Tämä on Backend-kurssin esimerkkisovellus. Tässä esimerkissä on kirjautuminen tietokantaan
        webbisovelluksessa.</p>
</div>