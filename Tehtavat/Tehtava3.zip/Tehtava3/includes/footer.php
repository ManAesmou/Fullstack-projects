<!-- Sivustojen alatunniste -->
</body>
<footer>
  <div class="mt-5 p-2 bg-dark text-white text-center">
    <hr>
      <p class="m-2">Ismo Manninen</p>
      <p class="m-2">TA42T21K</p>
    <hr>
  </div>
</footer>
</html>
